import{u}from"./index.77f349cd.js";const t=()=>{const o=u();return r=>{o.push({name:r})}};export{t as u};
