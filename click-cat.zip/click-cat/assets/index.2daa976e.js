import{_ as M,d as I,j as d,A as T,g as i,H as O,J as A,o as f,c as w,y as q,w as c,h as s,F as B,r as D,G as N,b,e as g,N as U,O as $,p as L,f as V,P as R,Q as K}from"./index.77f349cd.js";import{q as S}from"./http.4da0e1dc.js";import{b as k}from"./route-block.89f12ae7.js";const Q={class:"common-table-container"},j=I({__name:"CommonTable",props:{queryFunc:null},emits:["selectionChange"],setup(o,{expose:u,emit:_}){const n=o,r=d([]),p=d([]),l=d(!0),h=()=>{l.value=!0,n.queryFunc().then(e=>{r.value=e.meta.map(a=>({name:a.name})),p.value=e.data}).finally(()=>{l.value=!1})};T(()=>{h()});const y=e=>{_("selectionChange",e)};return u({refresh:()=>{h()}}),(e,a)=>{const t=i("el-table-column"),x=i("el-table"),v=O("loading");return A((f(),w("section",Q,[l.value?N("",!0):(f(),q(x,{key:0,data:p.value,style:{width:"100%"},height:"100%","tooltip-effect":"dark",border:!0,onSelectionChange:y},{default:c(()=>[s(t,{fixed:"left",type:"selection",width:"55"}),(f(!0),w(B,null,D(r.value,m=>(f(),q(t,{key:m.name,"show-overflow-tooltip":!0,prop:m.name,label:m.name,"min-width":"150"},null,8,["prop","label"]))),128))]),_:1},8,["data"]))])),[[v,l.value]])}}});var E=M(j,[["__scopeId","data-v-f320235c"]]);const H=()=>S(`SELECT
    now() as time,
    round(elapsed,1) as elapsed ,
    
    normalizeQuery(query) AS Query,
    1 as count,
    formatReadableSize(toUInt64(read_bytes)+toUInt64(written_bytes)) as bytes,
    toUInt64(toUInt64(read_rows) + toUInt64(written_rows)) as rows,
    formatReadableSize(peak_memory_usage) AS "peak memory",
    -- formatReadableSize(memory_usage) as "memory usage",
    formatReadableSize(read_bytes) as "read bytes",
    formatReadableSize(written_bytes) as "written bytes",  
    formatReadableSize(memory_usage) AS "memory usage",
    
    query_id,
    is_cancelled,
    user,
    multiIf(empty(client_name), http_user_agent, concat(client_name, ' ', toString(client_version_major), '.', toString(client_version_minor), '.', toString(client_version_patch))) AS client,
    
    cityHash64(normalizeQuery(query)) AS hash,
    thread_ids,
    ProfileEvents,
    Settings
    FROM system.processes


    FORMAT JSON
  `),J=()=>S(`
    SELECT
          database,
          table,
          mutation_id,
          command,
          create_time,
      parts_to_do_names,
      parts_to_do,
          is_done,
          latest_failed_part,
          latest_fail_time,
          latest_fail_reason
      FROM system.mutations
      ORDER BY create_time DESC
    FORMAT JSON`);const P=o=>(L("data-v-8a98a5a0"),o=o(),V(),o),W={class:"processes-container"},Y={class:"table-btn"},G=P(()=>b("span",null,"Kill",-1)),X=P(()=>b("span",null,"Refresh",-1)),z=I({__name:"index",setup(o){const u=d(null),_=d(null),n=d("Processes");let r=[],p=[];const l=e=>{r=e},h=e=>{p=e},y=async()=>{let e="";if(n.value==="Processes"){if(!r.length)return R({message:'Please select at least one piece of "Processes" data.',grouping:!0,type:"error"});const a=r.map(t=>`query_id ='${t.query_id}'`);e=`KILL QUERY WHERE ${a==null?void 0:a.join(" or ")}`}else if(n.value==="Mutations"){if(!r.length)return R({message:'Please select at least one piece of "Mutations" data.',grouping:!0,type:"error"});const a=p.map(t=>`database = '${t.database}' AND table = '${t.table}' AND mutation_id='${t.mutation_id}'`);e=`KILL MUTATION WHERE ${a==null?void 0:a.join(" or ")}`}await K.confirm("Kill selected data?","Kill",{confirmButtonText:"OK",cancelButtonText:"Cancel",type:"warning",customClass:"show-custom-primary-color"}),await S(e),n.value==="Processes"?await u.value.refresh():await _.value.refresh()},C=()=>{n.value==="Processes"?u.value.refresh():_.value.refresh()};return(e,a)=>{const t=i("el-icon"),x=i("el-divider"),v=i("el-tab-pane"),m=i("el-tabs");return f(),w("section",W,[b("section",Y,[b("div",{class:"btn",onClick:y},[s(t,{color:"#FF4D4F",style:{"margin-right":"8px"}},{default:c(()=>[s(g(U))]),_:1}),G]),s(x,{direction:"vertical"}),b("div",{class:"btn",onClick:C},[s(t,{color:"#59595F",style:{"margin-right":"8px"}},{default:c(()=>[s(g($))]),_:1}),X])]),s(m,{modelValue:n.value,"onUpdate:modelValue":a[0]||(a[0]=F=>n.value=F),type:"border-card"},{default:c(()=>[s(v,{label:"Processes",name:"Processes"},{default:c(()=>[s(E,{ref_key:"processesRef",ref:u,"query-func":g(H),onSelectionChange:l},null,8,["query-func"])]),_:1}),s(v,{label:"Mutations",lazy:!0,name:"Mutations"},{default:c(()=>[s(E,{ref_key:"mutationsRef",ref:_,"query-func":g(J),onSelectionChange:h},null,8,["query-func"])]),_:1})]),_:1},8,["modelValue"])])}}});typeof k=="function"&&k(z);var te=M(z,[["__scopeId","data-v-8a98a5a0"]]);export{te as default};
